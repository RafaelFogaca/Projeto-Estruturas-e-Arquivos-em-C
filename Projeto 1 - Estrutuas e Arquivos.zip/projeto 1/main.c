#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>      //cont�m declara��es para manipula��o de caracteres.
#include <locale.h>     //para o programa aceitar acentua��o
#define TAM 1000         //TAM recebe o valor de 100 inteiros

typedef struct Agenda
{
    char titulo[80];
    char descricao[100];
    char localizacao [100];
    char data[50];
    char hora[50];
    char alarme [50];
} cadastros;

/*============  Prototipos  ===============*/
void Incluir(void);    // fun��o para Incluir dados
void Listar(void);     // fun��o para Mostrar os contatos ja incluidos
void Organizar(void);  // fun��o para Colocar em ordem os contatos da agenda
void Pesquisar_data(void);  // fun��o para Pesquisar contatos
char AddMais();        // fun��o para Adicionar mais contatos na agenda
void Formata(void);    // fun��o para Apaga todos os contatos na agenda


/*============  Variaveis Globais  =============*/
static int qtd = 0;     // qtd � uma variavel do tipo estatica que conta a quantidade de contatos incritos
cadastros max[TAM];      // agora max[100] � um vetor do tipo contatos definido com o typedef
FILE *arq;              // declarar a

void alterar()
{
    int c;
    c=0;
    char numstr[10];
    system("cls");
    FILE*arq;
    cadastros;
    char nome[30];
    arq = fopen ("agenda.bin","rb+");
    char opc;

    if (arq == NULL)
    {
        printf("Erro ao abrir o arquivo..\n");
        system("pause");
    }
    else
    {
        fflush(stdin);
        printf("Digite o titulo a ser pesquisado.. \n");
        gets(nome);
        fread(&max,sizeof(cadastros),1,arq);

       while((!feof(arq) && strcmp(nome,max->titulo) !=0))
        {
            fread(&max,sizeof(cadastros),1,arq);
            c++;
        }
        if(feof(arq))
        {
            system("cls");
            printf("\a Titulo n�o consta no Arquivo...\n");
            getch();
        }
        else
        {
            fseek(arq, c*sizeof(cadastros),SEEK_SET);
            //... prints
            system("cls");
            printf ("Selecione uma op��o para alterar: \n");
            printf("\n 1 = Titulo\n 2 = descri��o\n 3 = Localiza��o\n");
            printf(" 4 = Data\n 5 = Hora\n 6 = Alarme\n 7 = Todos\n 8 = Cancelar\n\n");
            opc = getch();

            switch(opc)
            {
            case '1':
                system("cls");
                printf (" Digite o titulo: ");
                gets(max->titulo);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;
            case '2':
                system("cls");
                printf (" Digite o descri��o: ");
                gets(max->descricao);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;
            case '3':
                system("cls");
                printf (" Digite o localizac�o: ");
                gets(max->localizacao);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;
            case '4':
                system("cls");
                printf (" Digite a data: ");
                gets(max->data);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;
            case '5':
                system("cls");
                printf (" Digite o hora: ");
                gets(max->hora);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;
            case '6':
                system("cls");
                printf (" Digite o hor�rio do alarme: ");
                gets(max->alarme);


                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;

            case '7':
                system("cls");
                printf (" Digite o titulo: ");
                gets(max->titulo);
                printf (" Digite o descri��o: ");
                gets(max->descricao);
                printf (" Digite o localizac�o: ");
                gets(max->localizacao);
                printf (" Digite a data: ");
                gets(max->data);
                printf (" Digite o hora: ");
                gets(max->hora);
                printf (" Digite o hor�rio do alarme: ");
                gets(max->alarme);

                fwrite(&max, sizeof(cadastros),1,arq);
                printf("Registro alterado com sucesso...\n");
                break;

            case '8':
                system("cls");
                main();
                break;
            default:
                printf("\a Digite uma op��o valida\n");
                getch();//espera que o usu�rio pressione uma tecla
            }

        }
    }
    fclose(arq);
}
/*========  Incluir Contatos na Agenda  ===========*/

void Incluir(void)
{
    int cont = 0;   //cont sera a variavel contadora
    int retorno;    //retorno seve para definir se fwrite funcionou
    char op = 's';  //seve para definir a op��o na fun��o AddMais()
    char string2[100];
    char string3[100];
    char hr[80];
    char dt[80];
    char tt[80];

    int c;
    c=0;

    arq = fopen("agenda.bin", "rb+");// fopen cria arquivo de entrada
    if (arq == NULL)
    {
        printf("Erro ao abrir o arquivo..\n");
        system("pause");
    }
    else
    {
        fflush(stdin);
        printf("Digite a hora a ser adicionada (verifica��o).. \n");
        gets(hr);
        printf("\n Digite a data a ser adicionada (verifica��o) \n");
        gets(dt);
        printf("\n Digite o t�tulo a ser adicionado (verifica��o) \n");
        gets(tt);

        fread(&max,sizeof(cadastros),1,arq);

       while( ( ((!feof(arq))!=0) && ((strcmp(tt,max->titulo))!=0) ) ||  ( ( (!feof(arq))!=0) && ( (strcmp(hr,max->hora))!=0 ) ) || ( ( (!feof(arq))!=0 ) && ( (strcmp(dt,max->data)!=0) ) )   )
        {
            fread(&max,sizeof(cadastros),1,arq);
            c++;
        }

        if(feof(arq))
        {

                printf("\n Ap�s a verifica��o Digite o Agendamento\n");
                printf (" Digite o titulo: ");
                gets(max[cont].titulo);
                printf (" Digite o descri��o: ");
                gets(max[cont].descricao);
                printf (" Digite o localizac�o: ");
                gets(max[cont].localizacao);
                printf (" Digite a data: ");
                gets(max[cont].data);
                printf (" Digite o hora: ");
                gets(max[cont].hora);
                printf (" Digite o hor�rio do alarme: ");
                gets(max[cont].alarme);
                retorno = fwrite (&max[cont], sizeof(cadastros),1,arq);
                // fwrite retornara um valor int 1 para sucesso e 0 para fracasso
                if (retorno == 1)
                {
                    printf("\n Gravacao ok! ");
                }
                cont++;//enquanto cont for menor 100 adiciona mais um cadastro
                qtd++;//acrecenta 1 contato a mais


        }
        else
        {
            system("cls");
            printf("\a J� existe um compromisso com esses dados! tente novamente...\n");
            getch();
           }

fclose(arq);
    }
}
/*=====================  Apagar tudo  ====================*/
void Formata()
{
    /* w+ abre um arquivo para leitura e escrita.
    Se o arquivo n�o existir, o sistema operacional tentar� cri�-lo.
    Se o arquivo existir, todo o seu conte�do ser� substitu�do pelo novo conte�do.*/
    arq = fopen("agenda.bin","w+b"); //recria um arquivo limpo
    printf("\n\tLista limpa!\n ");
    fclose(arq);//fecha o arquivo agenda.bin
    getch();// espera que o usu�rio pressione uma tecla
}



/*============== Pesquisar cadastros =====================*/
void Pesquisar_data(void)
{

    int i=0, retorno=1, cont=0;
    char data[50],op;//A variavel nome se refere ao nome a ser pesquisado
    char hora[50];


    arq = fopen("agenda.bin", "rb");//fopen abre o arquivo no modo leitura "r"
    if (arq == NULL) //caso o SO n�o consiga abrir o arquivo
    {
        printf (" Erro!\nO arquivo da lista n�o pode ser aberto! \n");//sera mostrada esta mensagens
        getch();//espera que o usu�rio pressione uma tecla
        exit(1);//caso esse erro ocorra este comando encerra o programa
    }

    printf (" Digite a data: ");
    gets(data);
    printf (" Digite a hora: ");
    gets(hora);
    retorno = fread(&max[i], sizeof(cadastros), 1, arq);//fread le apenas 1 contato do arquivo

    while (retorno == 1) //o retorno recebe a quantidade de contatos lidos no fread
    {
        if ((strcmp(data, max[i].data) == 0) && (strcmp(hora, max[i].hora) == 0)) //strcmp compara as strings das variaveis
        {
            printf("\n titulo....: %s",max[i].titulo);
            printf("\n descri��o....: %s",max[i].descricao);
            printf("\n Localiza��o..: %s ",max[i].localizacao);
            printf("\n data....: %s",max[i].data);
            printf("\n hora..: %s ",max[i].hora);
            printf("\n hor�rio do alarme..: %s\n",max[i].alarme);
            cont++;
        }
        i++;
        retorno = fread(&max[i], sizeof(cadastros), 1, arq);//fread vai ler o proximo contato
    }
    if(cont == 0) //se strcmp n�o encontrar strings iguais
    {
        printf("Nao ha cadastros com este titulo!\n ");//sera mostrada essa mensagen
    }
    getch();//espera que o usu�rio pressione uma tecla
    fclose(arq);//fecha o arquivo agenda.txt
}



/*================== Lista os contatos cadastrados ======================*/

void Listar(void)
{
    int i = 0, retorno;

    arq = fopen("agenda.bin", "rb");//fopen abre o arquivo no modo leitura "r"
    if (arq == NULL) //caso o SO n�o consiga abrir o arquivo
    {
        printf ("Erro!\nO arquivo da lista n�o pode ser aberto!\n");//sera mostrada esta mensagens
        getch();//espera que o usu�rio pressione uma tecla
        exit(1);//caso esse erro ocorra este comando encerra o programa
    }
    retorno = fread(&max[i], sizeof(cadastros), 1, arq);//fread le apenas 1 contato do arquivo
    while (retorno == 1)  //o retorno recebe a quantidade de contatos lidos no fread
    {

        printf("\n\n compromisso n�mero %i \n",i);
        printf("\n titulo....: %s\n",max[i].titulo);
        printf("\n descri��o....: %s\n",max[i].descricao);
        printf("\n Localiza��o..: %s\n ",max[i].localizacao);
        printf("\n data....: %s\n",max[i].data);
        printf("\n hora..: %s\n ",max[i].hora);
        printf("\n hor�rio do alarme..: %s\n ",max[i].alarme);
        i++;
        retorno = fread(&max[i], sizeof(cadastros), 1, arq);//fread vai ler o proximo contato
    }
    printf(" \n\n %d Cadastros salvos!\n ", i);
    getch();//espera que o usu�rio pressione uma tecla
    fclose(arq);//fecha o arquivo agenda.txt
}



/*========== Sobre os Autores ================*/
void Sobre(void)
{
    printf("\n\n\t\tAGENDA EM LINGUAGUEM C\n\n");
    printf("\tTrabalho para obten��o de nota Parcial\n\tNa Disciplina de Algoritmos e Estrutura de Dados\n");
    printf("\tIntegrantes da Equipe:\n\t\tDaniel Galdencio - PC3006115\n\t\tAntonio Jose Naranjo - PC3006042\n\t\tLucas Patricio - PC3010147\n\t\tLeticia Abelha - PC300662X\n\t\tRafael Foga�a - PC3005551");
    getch();//espera que o usu�rio pressione uma tecla
}

/*=====================   Menu   =======================*/
void menu(void)
{   char dnv;
    char op;//variavel de op��o
    do
    {
        menu:
        system("cls");// limpar tela
        printf("\n\n\t\tAGENDA EM LINGUAGUEM C\n");
        printf("\n 1 = Incluir\n 2 = Listar por ordem de cadastro\n 3 = Pesquisar por data/hora\n");
        printf(" 4 = Formatar lista\n 5 = Atualizar cadastro \n 6 = Sobre\n 7 = Voltar\n 8 = Sair do programa\n");
        op = getch();
        switch(op)
        {
        case '1':
            incluir:
                system("cls");
            Incluir();
            dnv2:
            printf("Deseja Incluir mais agendamentos? (s/n)\n");
            scanf("%s",&dnv);
            if (dnv=='s'){
                goto incluir;
            }
            else {
             goto menu;
            }
            break;
        case '2':
            system("cls");
            Listar();
            break;
        case '3':
            system("cls");
            Pesquisar_data();
            break;
        case '4':
            Formata();
            break;
        case '5':
            alterar();
            break;
        case '6':
            system("cls");
            Sobre();
            break;
        case '7':
            system("cls");
            main();
            break;
        case '8':
            system("cls");
            exit(0);
            break;
        default:
            printf("\a Digite uma op��o valida\n");
            getch();//espera que o usu�rio pressione uma tecla
        }
    }
    while (op);
}

/*=========== Fun��o Principal ================*/
int main ()
{
    int var;
    system("title AGENDA");
    system("color f5");// Define a o plano de Fundo Azul Marinho e o texto em Branco
    setlocale(LC_ALL, "Portuguese");//Define no console o idioma Portugues
    printf("\n\n\t\tAGENDA EM LINGUAGUEM C\n\n");
    printf("\tVeja todas as fun��es disponiveis no menu.\n");
    printf("\tUse os numeros para selecionar a op��o desejada.\n");
    printf("\tPressione qualquer tecla para continuar ou\n\tEspa�o para sair do programa agora.\n\t");
    var=getch();
    if(var == 32)
    {
        exit(0);   // 32 corresponde a espa�o no teclado conforme Tabela ASCII
    }
    menu();// chamando a fun�ao menu para a main
    system("pause");
}
